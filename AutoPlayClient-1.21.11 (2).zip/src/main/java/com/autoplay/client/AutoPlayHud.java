package com.autoplay.client;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;

public final class AutoPlayHud {
    private AutoPlayHud() {}

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of(AutoPlayClientMod.MOD_ID, "status_hud"),
                AutoPlayHud::render
        );
    }

    private static void render(DrawContext drawContext, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) {
            return;
        }

        AutoPlayEngine engine = AutoPlayClientMod.getEngine();
        boolean enabled = engine.isEnabled();

        String title = enabled ? "AutoPlay AI [M]: ON" : "AutoPlay AI [M]: OFF";
        String modeLine = "Mode [N]: " + engine.getMode().label;
        String taskLine = "Task: " + engine.getStatusText();

        int padding = 6;
        int lineHeight = 11;
        int width = Math.max(
                client.textRenderer.getWidth(title),
                Math.max(client.textRenderer.getWidth(modeLine), client.textRenderer.getWidth(taskLine))
        ) + padding * 2;
        int height = enabled ? (lineHeight * 3 + padding * 2) : (lineHeight + padding * 2);

        int x = 8;
        int y = 8;

        int bgColor = enabled ? 0xB8101820 : 0x88101418;
        int accentColor = enabled ? 0xFF22C55E : 0xFFEF4444;

        drawContext.fill(x, y, x + width, y + height, bgColor);
        drawContext.fill(x, y, x + 3, y + height, accentColor);

        drawContext.drawTextWithShadow(
                client.textRenderer,
                title,
                x + padding + 2,
                y + padding,
                enabled ? 0xFF4ADE80 : 0xFFF87171
        );

        if (enabled) {
            drawContext.drawTextWithShadow(
                    client.textRenderer,
                    modeLine,
                    x + padding + 2,
                    y + padding + lineHeight,
                    0xFF93C5FD
            );
            drawContext.drawTextWithShadow(
                    client.textRenderer,
                    taskLine,
                    x + padding + 2,
                    y + padding + lineHeight * 2,
                    0xFFFDE68A
            );
        }
    }
}
