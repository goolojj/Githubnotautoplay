package com.autoplay.client;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class AutoPlayEngine {

    public enum Mode {
        AUTO_AI("AUTO AI"),
        TREE_FARM("TREE FARM"),
        MINING("MINING"),
        BUILD_HOUSE("BUILD HOUSE"),
        COMBAT_ONLY("COMBAT ONLY");

        public final String label;

        Mode(String label) {
            this.label = label;
        }
    }

    private boolean enabled = false;
    private Mode mode = Mode.AUTO_AI;
    private String statusText = "IDLE";

    private BlockPos currentBreakTarget = null;
    private BlockPos houseOrigin = null;
    private final List<BlockPos> houseBlueprint = new ArrayList<>();
    private int houseStepIndex = 0;
    private boolean houseBuilt = false;
    private int placeCooldown = 0;
    private int wanderTicks = 0;

    public boolean isEnabled() {
        return enabled;
    }

    public Mode getMode() {
        return mode;
    }

    public String getStatusText() {
        return statusText;
    }

    public boolean toggle(MinecraftClient client) {
        enabled = !enabled;
        if (!enabled) {
            releaseAllKeys(client);
            statusText = "IDLE";
            currentBreakTarget = null;
        } else {
            statusText = "STARTING AI";
        }
        return enabled;
    }

    public Mode cycleMode() {
        Mode[] values = Mode.values();
        mode = values[(mode.ordinal() + 1) % values.length];
        if (mode == Mode.BUILD_HOUSE) {
            houseBuilt = false;
            houseOrigin = null;
            houseBlueprint.clear();
            houseStepIndex = 0;
        }
        return mode;
    }

    public void tick(MinecraftClient client) {
        if (!enabled) {
            return;
        }

        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || client.interactionManager == null) {
            return;
        }

        if (client.currentScreen != null) {
            releaseAllKeys(client);
            statusText = "PAUSED (GUI OPEN)";
            return;
        }

        if (placeCooldown > 0) {
            placeCooldown--;
        }

        // Priority 1: Survival Auto-Eat
        if (handleAutoEat(client, player)) {
            return;
        }

        // Priority 2: Combat & Night Defense (Zombies, Skeletons, Spiders, Creeper Retreat)
        if (handleCombat(client, player, world)) {
            return;
        }

        // Priority 3: Mode / AI Planner
        switch (mode) {
            case COMBAT_ONLY -> {
                releaseAllKeys(client);
                statusText = "GUARDING (SAFE)";
            }
            case TREE_FARM -> handleTreeChopping(client, player, world);
            case MINING -> handleMining(client, player, world);
            case BUILD_HOUSE -> handleHouseBuilding(client, player, world);
            case AUTO_AI -> handleAutoAiBrain(client, player, world);
        }
    }

    private void handleAutoAiBrain(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        int buildingBlocks = countHotbarBuildingBlocks(player);

        // Step 1: Collect wood/blocks if low
        if (!houseBuilt && buildingBlocks < 28) {
            if (!handleTreeChopping(client, player, world)) {
                handleMining(client, player, world);
            }
            return;
        }

        // Step 2: Build starter house once we have enough blocks
        if (!houseBuilt && buildingBlocks >= 28) {
            handleHouseBuilding(client, player, world);
            return;
        }

        // Step 3: After house is built, alternate between ore mining and tree gathering
        if (!handleMining(client, player, world)) {
            handleTreeChopping(client, player, world);
        }
    }

    private boolean handleAutoEat(MinecraftClient client, ClientPlayerEntity player) {
        boolean needsFood = player.getHealth() < 13.0f || player.getHungerManager().getFoodLevel() < 14;
        if (!needsFood) {
            client.options.useKey.setPressed(false);
            return false;
        }

        int foodSlot = findFoodSlot(player);
        if (foodSlot == -1) {
            client.options.useKey.setPressed(false);
            return false;
        }

        releaseMovementKeys(client);
        player.getInventory().setSelectedSlot(foodSlot);
        client.options.useKey.setPressed(true);
        statusText = "AUTO-EATING";
        return true;
    }

    private boolean handleCombat(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        Box scanBox = player.getBoundingBox().expand(7.5, 4.0, 7.5);
        List<HostileEntity> hostiles = world.getEntitiesByClass(
                HostileEntity.class,
                scanBox,
                entity -> entity.isAlive() && !entity.isSpectator()
        );

        if (hostiles.isEmpty()) {
            return false;
        }

        HostileEntity nearest = null;
        double nearestSq = Double.MAX_VALUE;
        for (HostileEntity mob : hostiles) {
            double dSq = player.squaredDistanceTo(mob);
            if (dSq < nearestSq) {
                nearestSq = dSq;
                nearest = mob;
            }
        }

        if (nearest == null) {
            return false;
        }

        client.options.useKey.setPressed(false);

        // Smart Creeper Retreat: run away if Creeper is within 6 blocks
        if (nearest instanceof CreeperEntity && nearestSq < 36.0) {
            Vec3d playerPos = new Vec3d(player.getX(), player.getY(), player.getZ());
            Vec3d mobPos = new Vec3d(nearest.getX(), nearest.getY(), nearest.getZ());
            Vec3d awayTarget = playerPos.add(playerPos.subtract(mobPos).normalize().multiply(5.0));
            lookAt(player, awayTarget.add(0, 1.2, 0));
            client.options.forwardKey.setPressed(true);
            client.options.sprintKey.setPressed(true);
            client.options.jumpKey.setPressed(player.horizontalCollision);
            statusText = "RETREATING (CREEPER!)";
            return true;
        }

        // Equip sword or axe for melee combat
        if (!selectHotbarTag(player, ItemTags.SWORDS)) {
            selectHotbarTag(player, ItemTags.AXES);
        }

        Vec3d aimPos = new Vec3d(nearest.getX(), nearest.getY() + nearest.getHeight() * 0.65, nearest.getZ());
        lookAt(player, aimPos);

        if (nearestSq > 9.0) {
            client.options.forwardKey.setPressed(true);
            client.options.sprintKey.setPressed(true);
            client.options.jumpKey.setPressed(player.horizontalCollision);
        } else {
            releaseMovementKeys(client);
            if (player.getAttackCooldownProgress(0.5f) >= 0.9f && client.interactionManager != null) {
                client.interactionManager.attackEntity(player, nearest);
                player.swingHand(Hand.MAIN_HAND);
            }
        }

        statusText = "FIGHTING " + nearest.getType().getName().getString().toUpperCase();
        return true;
    }

    private boolean handleTreeChopping(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (currentBreakTarget == null || !world.getBlockState(currentBreakTarget).isIn(BlockTags.LOGS)) {
            currentBreakTarget = findNearestBlock(
                    world,
                    BlockPos.ofFloored(player.getX(), player.getY(), player.getZ()),
                    16,
                    state -> state.isIn(BlockTags.LOGS)
            );
        }

        if (currentBreakTarget == null) {
            wander(client, player, "SEARCHING TREES");
            return false;
        }

        selectHotbarTag(player, ItemTags.AXES);
        mineTargetBlock(client, player, currentBreakTarget, "CHOPPING TREE");
        return true;
    }

    private boolean handleMining(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (currentBreakTarget == null || !isDesiredMiningBlock(world.getBlockState(currentBreakTarget))) {
            BlockPos center = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ());
            // First prefer ores
            currentBreakTarget = findNearestBlock(world, center, 14, this::isOreBlock);
            // Fallback to stone/deepslate nearby
            if (currentBreakTarget == null) {
                currentBreakTarget = findNearestBlock(world, center, 10, this::isStoneBlock);
            }
        }

        if (currentBreakTarget == null) {
            wander(client, player, "SEARCHING ORES");
            return false;
        }

        selectHotbarTag(player, ItemTags.PICKAXES);
        mineTargetBlock(client, player, currentBreakTarget, "MINING");
        return true;
    }

    private void handleHouseBuilding(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (houseOrigin == null) {
            houseOrigin = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ()).add(2, 0, 2);
            buildStarterHouseBlueprint(houseOrigin);
            houseStepIndex = 0;
        }

        while (houseStepIndex < houseBlueprint.size()) {
            BlockPos target = houseBlueprint.get(houseStepIndex);
            if (!world.getBlockState(target).isReplaceable()) {
                houseStepIndex++;
            } else {
                break;
            }
        }

        if (houseStepIndex >= houseBlueprint.size()) {
            releaseAllKeys(client);
            houseBuilt = true;
            statusText = "HOUSE COMPLETE!";
            return;
        }

        int blockSlot = selectBuildingBlock(player);
        if (blockSlot == -1) {
            releaseAllKeys(client);
            statusText = "NEED BLOCKS FOR HOUSE";
            if (mode == Mode.AUTO_AI) {
                handleTreeChopping(client, player, world);
            }
            return;
        }

        BlockPos target = houseBlueprint.get(houseStepIndex);
        Vec3d targetCenter = Vec3d.ofCenter(target);
        Vec3d playerPos = new Vec3d(player.getX(), player.getY(), player.getZ());
        double distSq = playerPos.squaredDistanceTo(targetCenter);

        if (distSq > 16.0) {
            moveToward(client, player, targetCenter);
            statusText = "BUILDING HOUSE (" + houseStepIndex + "/" + houseBlueprint.size() + ")";
            return;
        }

        releaseMovementKeys(client);
        lookAt(player, targetCenter);

        if (placeCooldown == 0 && client.interactionManager != null) {
            BlockHitResult hit = findPlacementHit(world, target);
            if (hit != null) {
                client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
                player.swingHand(Hand.MAIN_HAND);
                placeCooldown = 3;
            } else {
                // Skip unreachable floating step
                houseStepIndex++;
            }
        }

        statusText = "BUILDING HOUSE (" + houseStepIndex + "/" + houseBlueprint.size() + ")";
    }

    private void buildStarterHouseBlueprint(BlockPos origin) {
        houseBlueprint.clear();
        // 5x5 walls, 3 blocks high (with 1x2 doorway on front south wall)
        for (int y = 0; y < 3; y++) {
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    boolean isPerimeter = (x == -2 || x == 2 || z == -2 || z == 2);
                    boolean isDoorway = (z == 2 && x == 0 && (y == 0 || y == 1));
                    if (isPerimeter && !isDoorway) {
                        houseBlueprint.add(origin.add(x, y, z));
                    }
                }
            }
        }
        // Flat 5x5 roof at y = 3
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                houseBlueprint.add(origin.add(x, 3, z));
            }
        }
    }

    private BlockHitResult findPlacementHit(ClientWorld world, BlockPos target) {
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction dir : order) {
            BlockPos support = target.offset(dir);
            if (!world.getBlockState(support).isReplaceable()) {
                Direction placeSide = dir.getOpposite();
                Vec3d hitPos = Vec3d.ofCenter(support).add(
                        placeSide.getOffsetX() * 0.5,
                        placeSide.getOffsetY() * 0.5,
                        placeSide.getOffsetZ() * 0.5
                );
                return new BlockHitResult(hitPos, placeSide, support, false);
            }
        }
        return null;
    }

    private void mineTargetBlock(MinecraftClient client, ClientPlayerEntity player, BlockPos target, String taskLabel) {
        Vec3d targetCenter = Vec3d.ofCenter(target);
        Vec3d eyePos = new Vec3d(player.getX(), player.getEyeY(), player.getZ());
        double distSq = eyePos.squaredDistanceTo(targetCenter);

        lookAt(player, targetCenter);

        if (distSq > 16.0) {
            moveToward(client, player, targetCenter);
            statusText = taskLabel + " (WALKING)";
        } else {
            releaseMovementKeys(client);
            if (client.interactionManager != null) {
                client.interactionManager.updateBlockBreakingProgress(target, Direction.UP);
                player.swingHand(Hand.MAIN_HAND);
            }
            statusText = taskLabel;
        }
    }

    private void wander(MinecraftClient client, ClientPlayerEntity player, String label) {
        wanderTicks++;
        if (wanderTicks % 60 == 0) {
            player.setYaw(player.getYaw() + 45.0f);
        }
        client.options.forwardKey.setPressed(true);
        client.options.sprintKey.setPressed(false);
        client.options.jumpKey.setPressed(player.horizontalCollision);
        statusText = label;
    }

    private void moveToward(MinecraftClient client, ClientPlayerEntity player, Vec3d target) {
        lookAt(player, target);
        client.options.forwardKey.setPressed(true);
        client.options.sprintKey.setPressed(true);
        client.options.jumpKey.setPressed(player.horizontalCollision);
    }

    private void lookAt(ClientPlayerEntity player, Vec3d target) {
        double dx = target.x - player.getX();
        double dy = target.y - player.getEyeY();
        double dz = target.z - player.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));

        player.setYaw(MathHelper.wrapDegrees(targetYaw));
        player.setPitch(MathHelper.clamp(targetPitch, -90.0f, 90.0f));
    }

    private BlockPos findNearestBlock(ClientWorld world, BlockPos center, int radius, Predicate<BlockState> matcher) {
        BlockPos best = null;
        double bestDistSq = Double.MAX_VALUE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -4; dy <= 8; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = center.add(dx, dy, dz);
                    BlockState state = world.getBlockState(pos);
                    if (matcher.test(state)) {
                        double dSq = pos.getSquaredDistance(center);
                        if (dSq < bestDistSq) {
                            bestDistSq = dSq;
                            best = pos;
                        }
                    }
                }
            }
        }
        return best;
    }

    private boolean isDesiredMiningBlock(BlockState state) {
        return isOreBlock(state) || isStoneBlock(state);
    }

    private boolean isOreBlock(BlockState state) {
        Block b = state.getBlock();
        return b == Blocks.COAL_ORE || b == Blocks.DEEPSLATE_COAL_ORE
                || b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE
                || b == Blocks.COPPER_ORE || b == Blocks.DEEPSLATE_COPPER_ORE
                || b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE
                || b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE;
    }

    private boolean isStoneBlock(BlockState state) {
        Block b = state.getBlock();
        return b == Blocks.STONE || b == Blocks.COBBLESTONE || b == Blocks.DEEPSLATE;
    }

    private boolean selectHotbarTag(ClientPlayerEntity player, TagKey<Item> tag) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.isIn(tag)) {
                player.getInventory().setSelectedSlot(i);
                return true;
            }
        }
        return false;
    }

    private int findFoodSlot(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.contains(DataComponentTypes.FOOD)) {
                return i;
            }
        }
        return -1;
    }

    private int countHotbarBuildingBlocks(ClientPlayerEntity player) {
        int count = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) {
                count += stack.getCount();
            }
        }
        return count;
    }

    private int selectBuildingBlock(ClientPlayerEntity player) {
        // First prefer planks, then logs, then any BlockItem
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.isIn(ItemTags.PLANKS)) {
                player.getInventory().setSelectedSlot(i);
                return i;
            }
        }
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) {
                player.getInventory().setSelectedSlot(i);
                return i;
            }
        }
        return -1;
    }

    private void releaseMovementKeys(MinecraftClient client) {
        client.options.forwardKey.setPressed(false);
        client.options.backKey.setPressed(false);
        client.options.jumpKey.setPressed(false);
        client.options.sprintKey.setPressed(false);
    }

    private void releaseAllKeys(MinecraftClient client) {
        releaseMovementKeys(client);
        client.options.useKey.setPressed(false);
        client.options.attackKey.setPressed(false);
    }
}
